#include <stdio.h>

int factrl (int number, long long  factorial) {
  factorial =1;
  while (number > 0)
    {
      factorial *= number;  // factorial = factorial*number;
      --number;
    }
  return factorial;
}
}
int main()
{
  int number;
  long long factorial;

  printf("Enter an integer: ");
  scanf("%d",&number);

  printf("The factorial is %lld",  factrl(number, factorial), "\n");
    
  return 1;
    }
}
