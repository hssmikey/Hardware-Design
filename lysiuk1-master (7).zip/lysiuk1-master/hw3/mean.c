#include <stdio.h>

double mean(double x, double y) {
  return((x+y)/2);
}

int main()
{
  double numb1, numb2;

  printf("Enter two integers :");
  scanf("%lf%lf", &numb1, &numb2);

  printf("The mean of %lf and %lf is", numb1, numb2);
  printf("%lf", mean(numb1,numb2));

  return 0;
}
