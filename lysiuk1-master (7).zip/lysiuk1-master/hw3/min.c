#include <stdio.h>

double min(double x, double y) {
  if (x > y)
    return y;
  else
    return x;
}

int main()
{
  double numb1, numb2;

  printf("Enter two integers :");
  scanf("%lf%lf", &numb1, &numb2);

  printf("The minimum of %lf and %lf is ", numb1, numb2);
  printf("%lf", min(numb1,numb2));

  return 0;
}
