#include <stdio.h>

double max(double x, double y) {
  if (x < y)
    return y;
  else
    return x;
}

int main()
{
  double numb1, numb2;

  printf("Enter two integers :");
  scanf("%d%d", &numb1, &numb2);

  printf("The maximum of %d and %d is", numb1, numb2);
  printf("%d", max(numb1,numb2);

  return 0;
}
