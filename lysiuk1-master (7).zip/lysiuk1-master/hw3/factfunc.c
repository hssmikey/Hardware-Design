#include <stdio.h>

// loop terminates when number is less than or equal to 0
int factrl (int number, long long  factorial) {
  factorial =1;
  while (number > 0)
    {
      factorial *= number;  // factorial = factorial*number;
      --number;
    }
  return factorial;
 }
}

int main()
{
  int number;
  long long factorial;
  
  printf("Enter an integer: ");
  scanf("%d",&number);


// loop terminates when number is less than or equal to 0
  if (0<= number && number <=10) {
      
    printf("Factorial of  %d is %d \n",  number, factrl(number));
    return 0;
  }
  else
    printf("%d is ont a small non-negative integer", n);
    
  return 1;
    }
}
