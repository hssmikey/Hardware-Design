#include <stdio.h>

double max(double x, double y) {
  if (x < y)
    return y;
  else
    return x;
}

int main()
{
  double numb1, numb2;

  printf("Enter two integers :");
  scanf("%lf%lf", &numb1, &numb2);

  printf("The call max(%lf, %lf) returns the value", numb1, numb2);
  printf("%lf", max(numb1,numb2));

  return 0;
}
