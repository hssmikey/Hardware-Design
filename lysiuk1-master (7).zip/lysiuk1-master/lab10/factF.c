#include <stdio.h>
int main()
{
  int number;
  long long factorial;

  printf("Enter an integer: ");
  scanf("%d",&number);

  factorial = 1;

  // loop terminates when number is less than or equal to 0
  for ( number > 0; number=number-1; )
    {
      factorial *= number;  // factorial = factorial*number;
     
    }

  printf("The factorial is %lld \n",  factorial, "\n");

  return 0;
}
