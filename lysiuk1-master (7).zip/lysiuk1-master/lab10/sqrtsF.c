#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main() {
  int N = 5;  /* number of square roots to print */
  int count = 0;  /* loop control variable */
  /* invariant:  count  square roots have been printed so far */
  for (count < N; count=count+1;) {
    printf("x \t", "sqrt(x) \n", "- \t", "------- \n");
    printf("%d\t%f\n", count+1, sqrt(count+1));
    
}
}  
