#include <stdio.h>
int main()
{
  int number;
  long long factorial;
  
  printf("Enter an integer: ");
  scanf("%d",&number);

  factorial = 1;

// loop terminates when number is less than or equal to 0
  if (number <=10) {
  while (number > 0)
    {
      factorial *= number;  // factorial = factorial*number;
      --number;
    }
  int N = 5;  /* number of square roots to print */
  int count = 0;  /* loop control variable */
  /* invariant:  count  square roots have been printed so far */
  while (count < N) {
    printf("%d\t%f\n", count+1, sqrt(count+1));
    count = count + 1;
    
  printf("The factorial is %lld",  factorial, "\n");
    
  return 1;
    }
}
