change:
.asciz "Please, enter your input line here: \n"
.align 2

prompt:
.asciz "Enter a line of input: \n"
.align 2

scanc:
.asciz "%c"
.align 2

scans:
.asciz "%d\n"
.align 2

output:
.asciz "Indices of characters %c: \n"
.align 2

testr:
.asciz "r4 is %c, and r5 is %c \n"
.align 2

summary:
.asciz "summary: \n %d characters \n"
.align 2

.text
.align 2

gettrans:
stmfd sp!, {fp, lr}
  add fp, sp, #4
  sub sp, sp, #40
  str r0, [fp, #-8]
  ldr r0,[fp, #-8]
  mov r1, #1
  bl get_byte
  str r0, [fp, #-12]
  ldr r0, [fp, #-12]
  cmp r0, #32
  beq equal
  mov r0, #1
  str r0, [fp, #-16]
  b continue

  equal:
  mov r0, #0
  str r0, [fp, #-16]

  continue:
  ldr r0, [fp, #-8]
  mov r1, #3
  bl get_byte
  str r0, [fp, #-28]
  ldr r0, [fp, #-28]
  cmp r0, #'\n'
  beq equaln
  mov r0, #1
  str r0, [fp, #-16]
  b continuen

  equaln:
  mov r0, #0
  str r0, [fp, #-16]

  continuen:
  ldr r0, [fp, #-8]
  mov r1, #4
  bl get_byte
  str r0, [fp, #-36]
  ldr r0, [fp, #-36]
  cmp r0, #'\0'
  beq equalu

  mov r0, #1
  str r0, [fp, #-16]
  b continueu

  equalu:
  mov r0, #0
  str r0, [fp, #-16]

  continueu:
  ldr r0, [fp, #-8]
  mov r1, #0
  bl get_byte
  str r0, [fp, #-20]
  ldr r4, [fp, #-20]
  ldr r0, [fp, #-8]
  mov r1, #2
  bl get_byte

  str r0, [fp, #-24]
  ldr r5, [fp, #-24]
  mov r0, #0
  sub sp, fp, #4
  ldmfd sp!, {fp, pc}

    .text
    .align 2

    translate:
    stmfd sp!, {fp, lr}
      add fp, sp, #4
      sub sp, sp, #52

      str r0, [fp, #-8]
      mov r6, #0
      str r4, [fp, #-16]
      str r5, [fp, #-20]
      mov r0, #0
      str r0, [fp, #-24]
      mov r1, #0
      str r1, [fp, #-44]
      b whilec

      loopb:
      ldr r0, [fp, #-8]
      ldr r1, [fp, #-24]
      bl get_byte
      str r0, [fp, #-28]
      ldr r0, [fp, #-28]
      ldr r1, [fpm #-16]
      cmp r0, r1
      bne loopn
      b next

      next:
      ldr r0, [fp, #-8]
      ldr r1, [fp, #-24]
      ldr r2, [fp, #-20]
      bl put_byte
      b addition

      addnline:
      str r7, [fp, #-40]
      ldr r0, [fp, #-40]
      add r0, r0, #1
      str r0, [fp, #-40]
      ldr r7, [fp, #-40]
      b continueb

      whilec:
      ldr r0, [fp, #-8]
      ldr r1, [fp, #-24]
      bl get_byte
      str r0, [fp, #-28]
      ldr r0, [fp, #-28]
      mov r1, #'\0'
      cmp r0, r1
      beq continueb
      b loopb

      loopn:
      ldr r0, [fp, #-8]
      ldr r1, [fp, #-24]
      bl get_byte
      str r0, [fp, #-28]
      ldr r0, [fp, #-28]
      cmp r0, #'\n'
      beq addnline
      b spacecheck

      spacecheck:
      ldr r0, [fp, #-8]
      ldr r1, [fp, #-24]
      bl get_byte
      str r0, [fp, #-28]
      ldr r0, [fp, #-28]
      cmp r0, #' '
      beq inwordcheck
      b casecheck

      assign:
      mov r0, #0
      str r0, [fp, #-44]
      b addition

      inwordcheck:
      ldr r1, [fp, #-44]
      cmp r1, #1
      beq assign
      b casecheck

      casecheck:
      ldr r0, [fp, #-8]
      ldr r1, [fp, #-24]
      bl get_byte
      str r0, [fp, #-28]
      ldr r0, [fp, #-28]
      cmp r0, #'A'
      blt addition
      cmp r0, #'Z'
      ble assign2
      cmp r0, #'a'
      blt addition
      cmp r0, #'z'
      bgt addition

      b addition

      assign2:
      ldr r0, [fp, #-44]
      cmp r0, #0
      bne addition
      b addition2

      addition2:
      str r2, [fp, #-48]
      ldr r0, [fp, #-48]
      add r0, r0, #1
      str r0, [fp, #-48]
      ldr r1, [fp, #-44]
      mov r1, #1
      str r1, [fp, #-44]
      b continueb

      addition:
      str r6, [fp, #-32]
      ldr r0, [fp, #-32]
      add r0,r0, #1
      str r0, [fp, #-32]
      ldr r6, [fp, #-32]
      ldr r0, [fp, #-24]
      add r0, r0, #1
      str r0, [fp, #-24]

      b whilec

      continueb:
      mov r0, #0
      sub sp, fp, #4
      ldmfd sp!, {fp, pc}

	.text
	.align 2

	print_summary:
	stmfd sp!, {fp, pc}
	  add fp, sp, #4
	  sub sp, sp, #8

	  str r6, [fp, #-8]
	  ldr r0, summaryP
	  ldr r1, [fp, #-8]
	  bl printf

	  mov r0, #0
	  sub sp, fp, #4
	  ldmfd sp!, {fp, pc}

	    .text
	    .align 2
	    .global main

	    main:
	    stmfd sp!, {fp, lr}
	    add fp, sp, #4
	    sub sp, sp, #40
	    ldr r0, buffP
	    mov r1, #100
	    bl get_line
	    ldr r0, buffP
	    bl gettrans
	    ldr r0, testrP
	    str r4, [fp, #-8]
	    ldr r1, [fp, #-8]
	    str r5, [fp, #-12]
	    ldr r2, [fp, #-12]
	    bl printf

	    mov r6, #0
	    str r6, [fp, #-16]
	    mov r7, #0
	    str r7, [fp, #-24]
	    mov r8, #0
	    str r8, [fp, #-28]

	    wguard:
	      ldr r0, buffP
		mov r1, #100
		bl get_line
		str r0, [fp, #-20]
		ldr r0, [fp, #-20]
		mov r1, #2
		cmp r0, r1
		blt guardfalse
		b guardtrue

		guardtrue:
	    ldr r0, buffP
	    bl translate

	    ldr r0, buffP
	    bl printf

	    guardfalse:
	    bl print_summary
	    mov r0, #0
	    sub sp, fp, #4
	    ldmfd sp!, {fp, pc}

	      .align 2

	      changeP: .word change
	      promptP: .word prompt
	      scancP: .word scanc
	      scansP: .word scans
	      outputP: .word output
	      testrP:         .word testr
	      summaryP: .word summary
	      buffP: .word buff

	      .data
	      .align 2

	      buff:.skip 100

	      
