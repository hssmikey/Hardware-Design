#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main() {
  float x,a,v,z,y;
  printf("Number to find the sqrt of \n");
  scanf("%f",&x);
  a=sqrt(x);
  printf("x=%f"," x is", x);

  printf("a=%f","The square root of x is ", a, "\n");

  if (v < 0) 
    printf("v is negative\n");
  else
    if (v > 0)
    printf("v is positive \n");
  else
    printf("v = 0 \n");
  z= (int) x;
  if (x==z)
    printf("x is an integer \n");
  else
    printf("x is not integer \n");
  y=(int)a;
  if (y==a)
    printf("root is an integer \n");
  else
    printf("root is not an integer \n");
  
  return 0;

}
